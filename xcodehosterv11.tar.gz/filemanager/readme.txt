Jangan hapus file login.php dan config.php juga folder recovery
